import TicketManagementBucketPage from '@/app/admin/components/dashboard/TicketManagementBucketPage';

export default function TicketManagementKpiProactivePage() {
  return (
    <TicketManagementBucketPage
      title='Proactive'
      description='Source PROACTIVE untuk family SQM dan SQM-CCAN, dengan detail yang tetap konsisten saat bucket dipilih.'
      icon='P'
      tone='emerald'
      operationalBucket={['kpi_proactive']}
      disableLocalSearch
    />
  );
}
