import TicketManagementBucketPage from '@/app/admin/components/dashboard/TicketManagementBucketPage';

export default function SqmUpdatePage() {
  return (
    <TicketManagementBucketPage
      title='SQM Update'
      description='Ticket SQM yang sudah di-flag update, tampil sebagai view tindak lanjut yang terpisah dan mudah dipindai.'
      icon='S'
      tone='slate'
      operationalBucket={['sqm_update']}
      disableLocalSearch
    />
  );
}
