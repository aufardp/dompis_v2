import { ChevronDown, ChevronUp } from 'lucide-react';
import clsx from 'clsx';
import CustomerTypeBadge from '../../../components/tickets/CustomerTypeBadge';
import { getStatusColor, getMaxTtr } from '../../../components/tickets/helpers';
import { TicketSeverity, SEVERITY_COLORS } from '@/app/libs/tickets/sort';
import { getEffectiveFlaggingLabel } from '@/app/libs/tickets/effective';
import { getEffectiveMaxTtrLabel } from '@/app/libs/tickets/effective';
import { getJenisStyle } from '@/app/libs/tickets/jenis';
import { TicketCtype } from '@/app/types/ticket';
import { formatDateTimeFullWIB } from '@/app/utils/datetime';
import { isTicketClosed } from '@/app/libs/ticket-utils';
import TtrCountdownBadge from './TtrCountdownBadge';
import MaxTtrCell from './MaxTtrCell';
import { TtrCountdown } from '@/app/hooks/useTtrCountdown';
import TicketActionButtons from '@/app/components/ui/TicketActionButtons';

export interface TicketRowProps {
  ticket: {
    idTicket?: number;
    ticket?: string;
    serviceNo?: string;
    ticketIdGamas?: string | null;
    contactName?: string | null;
    contactPhone?: string | null;
    alamat?: string | null;
    bookingDate?: string | null;
    ctype?: TicketCtype;
    customerType?: string;
    summary?: string;
    jenisTiket?: string;
    workzone?: string;
    technicianName?: string | null;
    teknisiUserId?: number | null;
    STATUS_UPDATE?: string | null;
    hasilVisit?: string | null;
    closedAt?: string | null;
    reportedDate?: string | null;
    status?: string | null;
    maxTtrReguler?: string | null;
    maxTtrGold?: string | null;
    maxTtrPlatinum?: string | null;
    maxTtrDiamond?: string | null;
    flaggingManja?: string | null;
    guaranteeStatus?: string | null;
  };
  onAssign: (ticketId: string | number) => void;
  onDetail?: (ticketId: string | number) => void;
  isExpanded?: boolean;
  onToggleExpand?: () => void;
  rank?: number;
  ticketAge?: string;
  severity?: TicketSeverity;
  slaLabel?: 'On Track' | 'At Risk' | 'Overdue';
  ttrCountdown?: TtrCountdown | null;
  selected?: boolean; // unused
  onSelect?: () => void; // unused
}

const SLA_STYLES = {
  'On Track': {
    badge:
      'bg-emerald-50 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400',
    dot: 'bg-emerald-500',
  },
  'At Risk': {
    badge:
      'bg-amber-50 text-amber-600 dark:bg-amber-500/15 dark:text-amber-300',
    dot: 'bg-amber-500',
  },
  Overdue: {
    badge: 'bg-red-50 text-red-600 dark:bg-red-500/15 dark:text-red-400',
    dot: 'bg-red-500',
  },
};

export default function TicketRow({
  ticket,
  onAssign,
  onDetail,
  isExpanded = false,
  onToggleExpand,
  rank,
  ticketAge,
  severity = 'normal',
  slaLabel,
  ttrCountdown,
  selected = false,
  onSelect,
}: TicketRowProps) {
  const severityStyles = SEVERITY_COLORS[severity];
  const isClosed = isTicketClosed(ticket.STATUS_UPDATE);
  const sla = slaLabel ? SLA_STYLES[slaLabel] : null;
  const techInitial = ticket.technicianName?.charAt(0).toUpperCase();

  const isGuarantee =
    String(ticket.guaranteeStatus ?? '')
      .trim()
      .toLowerCase() === 'guarantee';
  const gamasId = String(ticket.ticketIdGamas ?? '').trim();
  const hasValidGamasId =
    gamasId !== '' &&
    !['-', '--', 'null', 'undefined', 'n/a', 'na'].includes(
      gamasId.toLowerCase(),
    );
  const flagLabel = getEffectiveFlaggingLabel(ticket);

  // Perbaikan Max TTR Label: Memisahkan Tanggal dan Jam
  const maxTtrFullLabel = getEffectiveMaxTtrLabel(ticket);
  const [maxTtrDate, maxTtrTime] = maxTtrFullLabel
    ? maxTtrFullLabel.split(', ')
    : [null, null];

  const handleAssignClick = () => {
    onAssign(ticket.idTicket ?? '');
  };

  const handleDetailClick = () => {
    if (onDetail) {
      onDetail(ticket.idTicket ?? ticket.ticket ?? '');
    } else {
      onToggleExpand?.();
    }
  };

  return (
    <tr
      className={clsx(
        'group transition-colors duration-100 hover:bg-(--surface-2)',
        'border-l-4 px-3 py-2.5',
        severityStyles.border,
      )}
    >
      {/* Rank */}
      <td className='px-3 py-3 text-center'>
        <div className='flex items-center justify-center gap-1.5'>
          <span
            className={clsx(
              'h-4 w-1 rounded-full',
              severityStyles.border.replace('border-l-', 'bg-'),
            )}
            style={{
              background:
                severity === 'critical'
                  ? '#ef4444'
                  : severity === 'warning'
                    ? '#f59e0b'
                    : '#94a3b8',
            }}
          />
          <span className='font-mono text-sm font-bold text-(--text-primary)'>
            #{rank ?? '-'}
          </span>
        </div>
      </td>

      {/* Ticket ID + date */}
      <td className='px-4 py-3'>
        <p className='font-mono text-xs font-bold text-(--text-primary)'>
          {ticket.ticket}
        </p>
        <p className='mt-0.5 text-[10px] text-(--text-secondary)'>
          {ticket.reportedDate
            ? formatDateTimeFullWIB(ticket.reportedDate)
            : '-'}
        </p>
      </td>

      {/* Service No */}
      <td className='px-4 py-3 text-center'>
        <div className='inline-flex flex-wrap items-center justify-center gap-1'>
          <span className='font-mono text-xs text-(--text-primary)'>
            {ticket.serviceNo ?? '-'}
          </span>
          {isGuarantee && (
            <span className='rounded-md border border-rose-200 bg-rose-50 px-1.5 py-0.5 text-[10px] font-bold tracking-wide text-rose-700 dark:border-rose-400/20 dark:bg-rose-500/15 dark:text-rose-400'>
              FFG
            </span>
          )}
          {hasValidGamasId && (
            <span className='rounded-md border border-sky-200 bg-sky-50 px-1.5 py-0.5 text-[10px] font-medium text-sky-700 dark:border-sky-400/20 dark:bg-sky-500/15 dark:text-sky-400'>
              GAMAS {gamasId}
            </span>
          )}
        </div>
      </td>

      {/* Customer */}
      <td className='px-4 py-3'>
        <p className='text-sm leading-tight font-semibold text-(--text-primary) uppercase'>
          {ticket.contactName || '-'}
        </p>
        <p className='mt-0.5 text-[10px] text-(--text-secondary)'>
          {ticket.contactPhone || '-'}
        </p>
      </td>

      {/* Address */}
      <td className='max-w-40 px-4 py-3'>
        {ticket.alamat ? (
          <p className='line-clamp-2 text-xs leading-relaxed text-(--text-primary)'>
            {ticket.alamat}
          </p>
        ) : (
          <span className='text-xs text-(--text-secondary) italic'>—</span>
        )}
      </td>

      {/* Booking Date */}
      <td className='px-4 py-3 text-center'>
        <div className='inline-flex flex-col items-center justify-center'>
          <span className='text-xs text-(--text-secondary)'>
            {ticket.bookingDate
              ? formatDateTimeFullWIB(ticket.bookingDate).split(', ')[0]
              : '-'}
          </span>
          <span className='text-[10px] text-(--text-secondary) opacity-80'>
            {ticket.bookingDate
              ? formatDateTimeFullWIB(ticket.bookingDate).split(', ')[1]
              : ''}
          </span>
          {flagLabel && (
            <span
              className={clsx(
                'mt-1 rounded-full px-2 py-0.5 text-[10px] font-extrabold tracking-wide',
                flagLabel === 'P1'
                  ? 'bg-red-50 text-red-700 dark:bg-red-500/15 dark:text-red-400'
                  : 'bg-amber-50 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300',
              )}
              title='Flagging Manja'
            >
              {flagLabel}
            </span>
          )}
        </div>
      </td>

      {/* Customer Type */}
      <td className='px-4 py-3 text-center'>
        <CustomerTypeBadge ctype={ticket.ctype} size='sm' />
      </td>

      {/* Max TTR - FIXED RAPIH */}
      <td className='px-4 py-3 text-center align-middle'>
        {maxTtrFullLabel ? (
          <div className='flex flex-col items-center gap-1 leading-none'>
            {/* Tanggal Utama */}
            <span className='text-xs font-semibold text-(--text-primary)'>
              {maxTtrDate}
            </span>
            
            {/* Jam dengan font angka tetap (tabular) */}
            <span className='text-[10px] text-(--text-secondary) tabular-nums'>
              {maxTtrTime}
            </span>

            {/* Label Booking yang telah dirapikan menjadi Badge */}
            {ticket.bookingDate && (
              <span className='mt-0.5 inline-flex items-center rounded-full bg-blue-50 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider text-blue-600 ring-1 ring-inset ring-blue-500/20'>
                Booking
              </span>
            )}
          </div>
        ) : (
          <span className='text-xs text-(--text-secondary) italic'>—</span>
        )}
      </td>

      {/* Age + SLA */}
      <td className='px-4 py-3 text-center'>
        <div className='inline-flex flex-col items-center gap-0.5'>
          <span
            className={clsx(
              'rounded-full px-2.5 py-0.5 text-[11px] font-bold whitespace-nowrap',
              severityStyles.badge,
            )}
          >
            {ticketAge || '-'}
          </span>
          {sla && (
            <span
              className={clsx(
                'flex items-center gap-1 text-[9px] font-semibold',
                sla.badge.split(' ')[1],
              )}
            >
              <span className={clsx('h-1.5 w-1.5 rounded-full', sla.dot)} />
              {isClosed ? 'DONE' : slaLabel}
            </span>
          )}
          {!sla && isClosed && (
            <span className='rounded-full bg-gray-100 px-2 py-0.5 text-[9px] font-bold text-gray-500 dark:bg-gray-500/15 dark:text-gray-400'>
              STOPPED
            </span>
          )}
          <TtrCountdownBadge ticket={ticket} />
        </div>
      </td>

      {/* Jenis Tiket */}
      <td className='px-4 py-3 text-center'>
        {ticket.jenisTiket ? (
          <span
            className={clsx(
              'rounded-full px-2.5 py-0.5 text-[11px] font-semibold',
              getJenisStyle(ticket.jenisTiket),
            )}
          >
            {ticket.jenisTiket}
          </span>
        ) : (
          <span className='text-xs text-(--text-secondary) italic'>—</span>
        )}
      </td>

      {/* Workzone */}
      <td className='px-4 py-3 text-center'>
        <span className='text-xs font-semibold text-(--text-primary)'>
          {ticket.workzone ?? '-'}
        </span>
      </td>

      {/* Technician */}
      <td className='px-4 py-3 text-center'>
        {ticket.technicianName ? (
          <div className='inline-flex items-center gap-1.5'>
            <div className='flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-linear-to-br from-blue-500 to-indigo-600 text-[10px] font-bold text-white'>
              {techInitial}
            </div>
            <span
              className='max-w-20 truncate text-xs text-(--text-primary)'
              title={ticket.technicianName}
            >
              {ticket.technicianName}
            </span>
          </div>
        ) : (
          <span className='rounded-full border border-amber-200 bg-amber-50 px-2 py-0.5 text-[10px] font-semibold text-amber-600 dark:border-amber-400/20 dark:bg-amber-500/15 dark:text-amber-400'>
            Unassigned
          </span>
        )}
      </td>

      {/* Status */}
      <td className='px-4 py-3 text-center uppercase'>
        <span
          className={clsx(
            'inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[11px] font-semibold',
            getStatusColor(ticket.STATUS_UPDATE ?? ''),
          )}
        >
          {ticket.STATUS_UPDATE || '-'}
        </span>
      </td>

      {/* Action Button */}
      <td className='px-3 py-3 text-center'>
        <TicketActionButtons
          hasAssignee={!!ticket.teknisiUserId}
          isClosed={isClosed}
          onDetail={handleDetailClick}
          onAssign={handleAssignClick}
          size='sm'
        />
      </td>
    </tr>
  );
}
