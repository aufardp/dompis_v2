'use client';

import {
  RefreshCw,
  UserPlus,
  ChevronDown,
  ChevronUp,
  Eye,
  ShieldAlert,
  Tag,
  X,
} from 'lucide-react';
import { memo, useState } from 'react';
import { useRouter } from 'next/navigation';
import clsx from 'clsx';
import CustomerTypeBadge from '../../../components/tickets/CustomerTypeBadge';
import { getStatusColor, getMaxTtr } from '../../../components/tickets/helpers';
import { TicketSeverity, SEVERITY_COLORS } from '@/app/libs/tickets/sort';
import {
  getEffectiveFlaggingLabel,
  getEffectiveMaxTtrLabel,
} from '@/app/libs/tickets/effective';
import { getJenisStyle } from '@/app/config/jenis-tiket';
import { TicketCtype } from '@/app/types/ticket';
import { formatDateTimeFullWIB } from '@/app/utils/datetime';
import { isTicketClosed } from '@/app/libs/ticket-utils';
import { TtrCountdown } from '@/app/hooks/useTtrCountdown';
import TtrCountdownBadge from './TtrCountdownBadge';
import SqmUpdateModal from './SqmUpdateModal';
import BypassCloseModal from './BypassCloseModal';
import { useAdminToast } from './admin-toast';

export interface TicketRowProps {
  ticket: {
    idTicket?: number;
    ticket?: string;
    serviceNo?: string;
    contactName?: string | null;
    contactPhone?: string | null;
    alamat?: string | null;
    bookingDate?: string | null;
    ctype?: TicketCtype;
    customerType?: string;
    summary?: string;
    jenisTiket?: string;
    jenisTiket1?: string | null;
    workzone?: string;
    technicianName?: string | null;
    teknisiUserId?: number | null;
    hasilVisit?: string | null;
    closedAt?: string | null;
    reportedDate?: string | null;
    status?: string | null;
    maxTtrReguler?: string | null;
    maxTtrGold?: string | null;
    maxTtrPlatinum?: string | null;
    maxTtrDiamond?: string | null;
    flaggingManja?: string | null;
    guaranteeStatus?: string | null;
    status_update?: string | null;
    ticketIdGamas?: string | null;
    sqmUpdateReason?: string | null;
  };
  onAssign: (ticketId: string | number) => void;
  onDetail?: (ticketId: string | number) => void;
  isExpanded?: boolean;
  onToggleExpand?: (ticketId: number | string) => void;
  rank?: number;
  ticketAge?: string;
  severity?: TicketSeverity;
  slaLabel?: 'On Track' | 'At Risk' | 'Overdue';
  ttrCountdown?: TtrCountdown | null;
  highlighted?: boolean;
  showBypassClose?: boolean;
}

const SLA_STYLES = {
  'On Track': {
    badge:
      'bg-emerald-50 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400',
    dot: 'bg-emerald-500',
  },
  'At Risk': {
    badge:
      'bg-amber-50 text-amber-600 dark:bg-amber-500/15 dark:text-amber-300',
    dot: 'bg-amber-500',
  },
  Overdue: {
    badge: 'bg-red-50 text-red-600 dark:bg-red-500/15 dark:text-red-400',
    dot: 'bg-red-500',
  },
};

function formatStackedDateParts(dateValue: string | null | undefined) {
  if (!dateValue) {
    return { dayMonth: '-', year: '', time: '' };
  }

  const formatted = formatDateTimeFullWIB(dateValue);
  const [datePart = '', timePart = ''] = formatted.split(', ');
  const dateTokens = datePart.trim().split(/\s+/);

  if (dateTokens.length >= 3) {
    return {
      dayMonth: `${dateTokens[0]} ${dateTokens[1]}`,
      year: dateTokens.slice(2).join(' '),
      time: timePart,
    };
  }

  return {
    dayMonth: datePart || '-',
    year: '',
    time: timePart,
  };
}

function formatStackedLabelParts(labelValue: string | null | undefined) {
  if (!labelValue) {
    return { dayMonth: '-', year: '', time: '' };
  }

  const [datePart = '', timePart = ''] = labelValue.split(', ');
  const dateTokens = datePart.trim().split(/\s+/);

  if (dateTokens.length >= 3) {
    return {
      dayMonth: `${dateTokens[0]} ${dateTokens[1]}`,
      year: dateTokens.slice(2).join(' '),
      time: timePart,
    };
  }

  return {
    dayMonth: datePart || '-',
    year: '',
    time: timePart,
  };
}

function TicketRowB2B({
  ticket,
  onAssign,
  onDetail,
  isExpanded = false,
  onToggleExpand,
  rank,
  ticketAge,
  severity = 'normal',
  slaLabel,
  ttrCountdown,
  highlighted = false,
  showBypassClose = false,
}: TicketRowProps) {
  const severityStyles = SEVERITY_COLORS[severity];
  const isClosed = isTicketClosed(ticket.status_update ?? ticket.status_update);
  const sla = slaLabel ? SLA_STYLES[slaLabel] : null;
  const techInitial = ticket.technicianName?.charAt(0).toUpperCase();

  const isGuarantee =
    String(ticket.guaranteeStatus ?? '')
      .trim()
      .toLowerCase() === 'guarantee';
  const gamasId = String(ticket.ticketIdGamas ?? '').trim();
  const hasValidGamasId =
    gamasId !== '' &&
    !['-', '--', 'null', 'undefined', 'n/a', 'na'].includes(
      gamasId.toLowerCase(),
    );
  const flagLabel = getEffectiveFlaggingLabel(ticket);
  const bookingDateParts = formatStackedDateParts(ticket.bookingDate);

  const isSqmTicket = (ticket.jenisTiket1 ?? '').toLowerCase().includes('sqm');
  const hasSqmUpdate = (ticket.summary ?? '').startsWith('[SQM-UPDATE]');

  // Helper untuk memproses label Max TTR agar rapi (Stacked)
  const maxTtrFullLabel = getEffectiveMaxTtrLabel(ticket);
  const maxTtrParts = formatStackedLabelParts(maxTtrFullLabel);

  const handleAssignClick = () => {
    onAssign(ticket.idTicket ?? '');
  };

  const handleDetailClick = () => {
    if (onDetail) {
      onDetail(ticket.idTicket ?? ticket.ticket ?? '');
    } else {
      onToggleExpand?.(ticket.idTicket ?? ticket.ticket ?? '');
    }
  };

  const [sqmModalOpen, setSqmModalOpen] = useState(false);
  const [bypassModalOpen, setBypassModalOpen] = useState(false);
  const [bypassLoading, setBypassLoading] = useState(false);
  const { showSuccess, showError } = useAdminToast();
  const router = useRouter();

  const handleSqmConfirm = async (reason: string, description: string) => {
    const currentSummary = ticket.summary ?? '';
    try {
      const res = await fetch('/api/tickets/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ticketId: ticket.idTicket,
          patch: {
            summary: `[SQM-UPDATE][${reason}] ${currentSummary}`.trim(),
            sqmUpdateReason: description,
          },
        }),
      });

      const payload = await res.json().catch(() => null);

      if (!res.ok) {
        showError(
          'SQM update gagal',
          payload?.message ?? 'Ticket tidak berhasil ditandai SQM-UPDATE.',
        );
        return;
      }

      showSuccess(
        'SQM update berhasil',
        ticket.ticket
          ? `Ticket ${ticket.ticket} sudah ditandai SQM-UPDATE.`
          : 'Ticket sudah ditandai SQM-UPDATE.',
        { persist: true },
      );
      setSqmModalOpen(false);
      router.refresh();
    } catch (e) {
      showError(
        'SQM update gagal',
        'Terjadi kesalahan saat memproses SQM-UPDATE.',
      );
    }
  };

  const handleBypassClose = async () => {
    if (!ticket.idTicket || bypassLoading) return;

    setBypassLoading(true);
    try {
      const res = await fetch('/api/tickets/bypass-close', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ticketId: ticket.idTicket }),
      });
      const payload = await res.json().catch(() => null);

      if (!res.ok || !payload?.success) {
        showError(
          'Bypass close gagal',
          payload?.message ?? 'Ticket tidak berhasil di-bypass close.',
        );
        return;
      }

      showSuccess(
        'Bypass close berhasil',
        ticket.ticket ? `Ticket ${ticket.ticket} sudah masuk validasi.` : 'Ticket sudah masuk validasi.',
        { persist: true },
      );
      router.refresh();
    } catch (e) {
      console.error('Bypass close error:', e);
      showError(
        'Bypass close gagal',
        'Terjadi kesalahan saat memproses bypass close.',
      );
    } finally {
      setBypassLoading(false);
      setBypassModalOpen(false);
    }
  };

  return (
    <>
    <tr
      className={clsx(
        'group border-l-4 transition-colors duration-100 scroll-mt-28',
        highlighted
          ? 'border-l-blue-500 bg-blue-50/70 shadow-[inset_0_0_0_1px_rgba(59,130,246,0.08)] dark:bg-blue-500/10'
          : severityStyles.border,
        'hover:bg-(--surface-2)',
      )}
      data-search-highlight={highlighted ? 'true' : undefined}
    >
      {/* Rank */}
      <td className='px-3 py-3 text-center'>
        <div className='flex items-center justify-center gap-1.5'>
          <span
            className={clsx(
              'h-4 w-1 rounded-full',
              severityStyles.border.replace('border-l-', 'bg-'),
            )}
            style={{
              background:
                severity === 'critical'
                  ? '#ef4444'
                  : severity === 'warning'
                    ? '#f59e0b'
                    : '#94a3b8',
            }}
          />
          <span className='font-mono text-sm font-bold text-(--text-primary)'>
            #{rank ?? '-'}
          </span>
        </div>
      </td>

      {/* Ticket ID + date */}
      <td className='px-4 py-3'>
        <p className='font-mono text-xs font-bold text-(--text-primary)'>
          {ticket.ticket}
        </p>
        <p className='mt-0.5 text-[10px] text-(--text-secondary)'>
          {ticket.reportedDate
            ? formatDateTimeFullWIB(ticket.reportedDate)
            : '-'}
        </p>
      </td>

      {/* Service No */}
      <td className='px-4 py-3 text-center'>
        <div className='inline-flex flex-wrap items-center justify-center gap-1'>
          <span className='font-mono text-xs text-(--text-primary)'>
            {ticket.serviceNo ?? '-'}
          </span>
          {hasSqmUpdate && (
            <span className='rounded-md border border-violet-200 bg-violet-100 px-1.5 py-0.5 text-[10px] font-bold tracking-wide text-violet-800 dark:border-violet-500/30 dark:bg-violet-500/20 dark:text-violet-300'>
              SQM-UPDATE
            </span>
          )}
          {isGuarantee && (
            <span className='rounded-md border border-rose-200 bg-rose-50 px-1.5 py-0.5 text-[10px] font-bold tracking-wide text-rose-700 dark:border-rose-400/20 dark:bg-rose-500/15 dark:text-rose-400'>
              FFG
            </span>
          )}
          {hasValidGamasId && (
            <span className='rounded-md border border-sky-200 bg-sky-50 px-1.5 py-0.5 text-[10px] font-bold tracking-wide text-sky-700 dark:border-sky-400/20 dark:bg-sky-500/15 dark:text-sky-400'>
              GAMAS {gamasId}
            </span>
          )}
        </div>
      </td>

      {/* Customer */}
      <td className='px-4 py-3'>
        <p className='text-sm leading-tight font-semibold text-(--text-primary) uppercase'>
          {ticket.contactName || '-'}
        </p>
        <p className='mt-0.5 text-[10px] text-(--text-secondary)'>
          {ticket.contactPhone || '-'}
        </p>
      </td>

      {/* Address */}
      <td className='max-w-40 px-4 py-3'>
        {ticket.alamat ? (
          <p className='line-clamp-2 text-xs leading-relaxed text-(--text-primary)'>
            {ticket.alamat}
          </p>
        ) : (
          <span className='text-xs text-(--text-secondary) italic'>—</span>
        )}
      </td>

      {/* Booking Date - RAPIH (Stacked) */}
      <td className='px-4 py-3 text-center'>
        <div className='flex flex-col items-center justify-center leading-tight'>
          <span className='text-xs text-(--text-secondary)'>
            {bookingDateParts.dayMonth}
          </span>
          <span className='text-[10px] text-(--text-secondary) opacity-80'>
            {bookingDateParts.year}
          </span>
          <span className='text-[10px] text-(--text-secondary) opacity-80'>
            {bookingDateParts.time}
          </span>
          {flagLabel && (
            <span
              className={clsx(
                'mt-1 rounded-full px-2 py-0.5 text-[10px] font-extrabold tracking-wide',
                flagLabel === 'P1'
                  ? 'bg-red-50 text-red-700 dark:bg-red-500/15 dark:text-red-400'
                  : flagLabel === 'P+'
                    ? 'bg-amber-50 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300'
                    : 'bg-slate-100 text-slate-700 dark:bg-slate-500/20 dark:text-slate-300',
              )}
            >
              {flagLabel === 'P1'
                ? 'Manja HI'
                : flagLabel === 'P+'
                  ? 'Manja H+'
                  : flagLabel === 'EXPIRED'
                    ? 'Manja Expired'
                  : flagLabel}
            </span>
          )}
        </div>
      </td>

      {/* Customer Type */}
      <td className='px-4 py-3 text-center'>
        {ticket.jenisTiket1 ? (
          <div className='flex flex-col items-center gap-0.5'>
            <span className='text-xs font-semibold text-(--text-primary)'>
              {ticket.jenisTiket1}
            </span>
          </div>
        ) : ticket.jenisTiket ? (
          <span
            className={clsx(
              'rounded-full px-2.5 py-0.5 text-[11px] font-semibold',
              getJenisStyle(ticket.jenisTiket),
            )}
          >
            {ticket.jenisTiket}
          </span>
        ) : (
          <span className='text-xs text-(--text-secondary) italic'>—</span>
        )}
      </td>

      {/* Max TTR - RAPIH (Stacked) */}
      <td className='px-4 py-3 text-center align-middle'>
        {maxTtrFullLabel ? (
          <div className='flex flex-col items-center gap-1 leading-none'>
            <span className='text-xs font-semibold text-(--text-primary)'>
              {maxTtrParts.dayMonth}
            </span>
            <span className='text-[10px] text-(--text-secondary) opacity-80'>
              {maxTtrParts.year}
            </span>
            <span className='text-[10px] text-(--text-secondary) tabular-nums'>
              {maxTtrParts.time}
            </span>

            {ticket.bookingDate && (
              <span className='mt-0.5 inline-flex items-center rounded-full bg-blue-50 px-2 py-0.5 text-[9px] font-bold tracking-wider text-blue-600 uppercase ring-1 ring-blue-500/20 ring-inset'>
                Booking
              </span>
            )}
          </div>
        ) : (
          <span className='text-xs text-(--text-secondary) italic'>—</span>
        )}
      </td>

      {/* Age + SLA */}
      <td className='px-4 py-3 text-center'>
        <div className='inline-flex flex-col items-center gap-0.5'>
          <span
            className={clsx(
              'rounded-full px-2.5 py-0.5 text-[11px] font-bold whitespace-nowrap',
              severityStyles.badge,
            )}
          >
            {ticketAge || '-'}
          </span>
          {sla && (
            <span
              className={clsx(
                'flex items-center gap-1 text-[9px] font-semibold',
                sla.badge.split(' ')[1],
              )}
            >
              <span className={clsx('h-1.5 w-1.5 rounded-full', sla.dot)} />
              {isClosed ? 'DONE' : slaLabel}
            </span>
          )}
          {!sla && isClosed && (
            <span className='rounded-full bg-gray-100 px-2 py-0.5 text-[9px] font-bold text-gray-500 dark:bg-gray-500/15 dark:text-gray-400'>
              STOPPED
            </span>
          )}
          <TtrCountdownBadge ticket={ticket} />
        </div>
      </td>

      {/* Jenis Tiket - Parent Group (jenis_tiket_1) */}
      <td className='px-4 py-3 text-center'>
        {ticket.jenisTiket ? (
          <span
            className={clsx(
              'rounded-full px-2.5 py-0.5 text-[11px] font-semibold',
              getJenisStyle(ticket.jenisTiket),
            )}
          >
            {ticket.jenisTiket}
          </span>
        ) : (
          <span className='text-xs text-(--text-secondary) italic'>—</span>
        )}
      </td>

      {/* Workzone */}
      <td className='px-4 py-3 text-center'>
        <span className='text-xs font-semibold text-(--text-primary)'>
          {ticket.workzone ?? '-'}
        </span>
      </td>

      {/* Technician */}
      <td className='px-4 py-3 text-center'>
        {ticket.technicianName ? (
          <div className='inline-flex items-center gap-1.5'>
            <div className='flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-linear-to-br from-blue-500 to-indigo-600 text-[10px] font-bold text-white'>
              {techInitial}
            </div>
            <span
              className='max-w-20 truncate text-xs text-(--text-primary)'
              title={ticket.technicianName}
            >
              {ticket.technicianName}
            </span>
          </div>
        ) : (
          <span className='rounded-full border border-amber-200 bg-amber-50 px-2 py-0.5 text-[10px] font-semibold text-amber-600 dark:border-amber-400/20 dark:bg-amber-500/15 dark:text-amber-400'>
            Unassigned
          </span>
        )}
      </td>

      {/* Status */}
      <td className='px-4 py-3 text-center uppercase'>
        <span
          className={clsx(
            'inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[11px] font-semibold',
            getStatusColor(ticket.status ?? ticket.status ?? ''),
          )}
        >
          {(ticket.status ?? ticket.status) || '-'}
        </span>
      </td>

      <td className='px-4 py-3 text-center uppercase'>
        <span
          className={clsx(
            'inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[11px] font-semibold',
            getStatusColor(ticket.status_update ?? ticket.status_update ?? ''),
          )}
        >
          {(ticket.status_update ?? ticket.status_update) || '-'}
        </span>
      </td>

      {/* Action Buttons */}
      <td className='px-3 py-3 text-center'>
        {isClosed ? (
          <button
            onClick={handleDetailClick}
            title='Lihat Detail'
            className='bg-surface inline-flex items-center gap-1.5 rounded-xl border border-(--border) px-3 py-1.5 text-xs font-semibold text-(--text-secondary) transition hover:bg-blue-50 hover:text-blue-600 dark:hover:bg-blue-500/15 dark:hover:text-blue-400'
          >
            <Eye size={13} />
          </button>
        ) : (
          <div className='inline-flex overflow-hidden rounded-xl border border-(--border) shadow-sm'>
            {showBypassClose && (
              <button
                onClick={() => setBypassModalOpen(true)}
                className='bg-surface flex items-center gap-1.5 border-r border-(--border) px-3 py-1.5 text-xs font-semibold text-amber-700 transition hover:bg-amber-50 hover:text-amber-800 dark:text-amber-300 dark:hover:bg-amber-500/15 dark:hover:text-amber-200'
                title='Bypass Close'
              >
                <ShieldAlert size={13} />
              </button>
            )}
            {isSqmTicket && !hasSqmUpdate && (
              <button
                onClick={() => setSqmModalOpen(true)}
                className='bg-surface flex items-center gap-1.5 border-r border-(--border) px-3 py-1.5 text-xs font-semibold text-violet-600 transition hover:bg-violet-50 hover:text-violet-700 dark:text-violet-400 dark:hover:bg-violet-500/15 dark:hover:text-violet-300'
                title='Tandai sebagai SQM Update'
              >
                <Tag size={13} />
              </button>
            )}
            {isSqmTicket && hasSqmUpdate && (
              <button
                onClick={async () => {
                  const currentSummary = ticket.summary ?? '';
                  try {
                    const res = await fetch('/api/tickets/update', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({
                        ticketId: ticket.idTicket,
                        patch: {
                          summary: currentSummary
                            .replace(/^\[SQM-UPDATE\]\[.*?\]\s*/, '')
                            .replace(/^\[SQM-UPDATE\]\s*/, ''),
                          sqmUpdateReason: null,
                        },
                      }),
                    });
                    const payload = await res.json().catch(() => null);

                    if (!res.ok) {
                      showError(
                        'SQM update gagal',
                        payload?.message ??
                          'SQM-UPDATE pada ticket ini tidak dapat dibatalkan.',
                      );
                      return;
                    }

                    showSuccess(
                      'SQM update dibatalkan',
                      ticket.ticket
                        ? `Ticket ${ticket.ticket} kembali normal.`
                        : 'Ticket kembali normal.',
                      { persist: true },
                    );
                    router.refresh();
                  } catch (e) {
                    showError(
                      'SQM update gagal',
                      'Terjadi kesalahan saat membatalkan SQM-UPDATE.',
                    );
                  }
                }}
                className='bg-surface flex items-center gap-1.5 border-r border-(--border) px-3 py-1.5 text-xs font-semibold text-rose-600 transition hover:bg-rose-50 hover:text-rose-700 dark:text-rose-400 dark:hover:bg-rose-500/15 dark:hover:text-rose-300'
                title='Batalkan SQM Update'
              >
                <X size={13} />
              </button>
            )}
            <button
              onClick={handleDetailClick}
              title='Lihat Detail'
              className='bg-surface flex items-center gap-1.5 border-r border-(--border) px-3 py-1.5 text-xs font-semibold text-(--text-secondary) transition hover:bg-blue-50 hover:text-blue-600 dark:hover:bg-blue-500/15 dark:hover:text-blue-400'
            >
              <Eye size={13} />
            </button>
            <button
              onClick={handleAssignClick}
              title={ticket.teknisiUserId ? 'Reassign Teknisi' : 'Assign Teknisi'}
              className={clsx(
                'flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white transition',
                ticket.teknisiUserId
                  ? 'bg-amber-500 hover:bg-amber-600 dark:bg-amber-600 dark:hover:bg-amber-500'
                  : 'bg-blue-600 hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-600',
              )}
            >
              {ticket.teknisiUserId ? <RefreshCw size={13} /> : <UserPlus size={13} />}
            </button>
          </div>
        )}
      </td>
    </tr>
    <SqmUpdateModal
      open={sqmModalOpen}
      onClose={() => setSqmModalOpen(false)}
      onConfirm={handleSqmConfirm}
    />
    <BypassCloseModal
      open={bypassModalOpen}
      onClose={() => setBypassModalOpen(false)}
      onConfirm={handleBypassClose}
      ticketCode={ticket.ticket}
      loading={bypassLoading}
  />
  </>
  );
}

export default memo(TicketRowB2B);
