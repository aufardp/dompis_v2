'use client';

import type { ReactNode } from 'react';
import { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import dynamic from 'next/dynamic';
import { Activity, Clock3, Flame, MoonStar, SunMedium } from 'lucide-react';
import { toZonedTime, format } from 'date-fns-tz';
import { ChartContainer } from '@/app/components/ui/chart';
import { fetchWithAuth } from '@/app/libs/fetcher';
import { queryKeys } from '@/app/libs/query-keys';
import { useWorkzoneOptions } from '@/app/hooks/useDropdownOptions';

const HourlyCloseChart = dynamic(() => import('./HourlyCloseChart'), { ssr: false });

type HourlyCloseRow = {
  hour: number;
  count: number;
};

const ALL_HOURS = Array.from({ length: 24 }, (_, hour) => ({
  hour,
  label: `${String(hour).padStart(2, '0')}:00`,
  shortLabel: String(hour).padStart(2, '0'),
  count: 0,
}));

const WIB_TIMEZONE = 'Asia/Jakarta';

function formatNumber(value: number): string {
  return new Intl.NumberFormat('id-ID').format(value);
}

function getWibNow(): Date {
  return toZonedTime(new Date(), WIB_TIMEZONE);
}

function getHourBadge(hour: number): string {
  if (hour >= 5 && hour <= 10) return 'Pagi';
  if (hour >= 11 && hour <= 15) return 'Siang';
  if (hour >= 16 && hour <= 18) return 'Sore';
  return 'Malam';
}

function getBarFill(
  hour: number,
  count: number,
  currentHour: number,
  peakHour: number | null,
): string {
  if (count === 0) return 'rgba(148, 163, 184, 0.20)';
  if (peakHour === hour) return '#10b981';
  if (currentHour === hour) return '#f59e0b';
  if (count >= 8) return '#38bdf8';
  if (count >= 4) return '#60a5fa';
  return '#7c3aed';
}

function StatPill({
  label,
  value,
  sub,
  icon,
}: {
  label: string;
  value: string;
  sub: string;
  icon: ReactNode;
}) {
  return (
    <div className='rounded-xl border border-(--border) bg-(--surface-2) px-3 py-2'>
      <div className='flex items-center justify-between gap-2'>
        <p className='text-[10px] font-semibold tracking-[0.18em] text-(--text-muted) uppercase'>
          {label}
        </p>
        <div className='text-(--text-muted)'>{icon}</div>
      </div>
      <div className='mt-2 flex items-end justify-between gap-3'>
        <p className='text-[1rem] leading-none font-bold text-(--text-primary)'>
          {value}
        </p>
        <p className='text-right text-[11px] leading-tight text-(--text-secondary)'>
          {sub}
        </p>
      </div>
    </div>
  );
}

function HourChip({
  hour,
  count,
  currentHour,
  peakHour,
}: {
  hour: number;
  count: number;
  currentHour: number;
  peakHour: number | null;
}) {
  const active = count > 0;
  const isCurrent = hour === currentHour;
  const isPeak = hour === peakHour;

  return (
    <div
      className='flex min-w-0 flex-1 flex-col items-center gap-1 rounded-lg border px-1.5 py-2 text-center'
      style={{
        borderColor: isPeak
          ? 'rgba(16, 185, 129, 0.35)'
          : isCurrent
            ? 'rgba(245, 158, 11, 0.35)'
            : 'var(--border)',
        background: isPeak
          ? 'rgba(16, 185, 129, 0.08)'
          : isCurrent
            ? 'rgba(245, 158, 11, 0.08)'
            : 'var(--surface-2)',
      }}
    >
      <span className='text-[10px] font-semibold text-(--text-muted)'>
        {String(hour).padStart(2, '0')}
      </span>
      <div
        className='w-full rounded-full'
        style={{
          height: `${Math.max(6, Math.min(28, count * 3))}px`,
          background: active
            ? isPeak
              ? '#10b981'
              : isCurrent
                ? '#f59e0b'
                : '#38bdf8'
            : 'rgba(148, 163, 184, 0.18)',
        }}
      />
      <span className='font-mono text-[10px] font-bold text-(--text-secondary)'>
        {count}
      </span>
    </div>
  );
}

export default function RekapWorkorderHourlyClose({
  bucket,
}: {
  bucket?: string;
}) {
  const [selectedWorkzone, setSelectedWorkzone] = useState('');
  const { options: workzoneOptions, loading: workzoneLoading } =
    useWorkzoneOptions();
  const { data, isLoading, isFetching } = useQuery({
    queryKey: queryKeys.dashboard.rekapWorkorderHourly(
      `${bucket || 'all'}:${selectedWorkzone || 'all'}`,
    ),
    queryFn: async () => {
      const params = new URLSearchParams();
      if (bucket && bucket !== 'all') params.set('bucket', bucket);
      if (selectedWorkzone) params.set('workzone', selectedWorkzone);
      const url = params.toString()
        ? `/api/dashboard/rekap-workorder/hourly-close?${params.toString()}`
        : '/api/dashboard/rekap-workorder/hourly-close';
      const res = await fetchWithAuth(url);
      if (!res) throw new Error('No response');
      const json = await res.json();
      if (!json?.success) throw new Error(json?.message || 'Failed');
      return json.data as HourlyCloseRow[];
    },
    staleTime: 30_000,
    refetchOnWindowFocus: false,
  });

  const now = getWibNow();
  const currentHour = now.getHours();
  const dateLabel = format(now, 'EEEE, dd MMM yyyy', {
    timeZone: WIB_TIMEZONE,
  });

  const chartData = useMemo(() => {
    if (!data) return ALL_HOURS;
    const map = new Map(data.map((item) => [item.hour, item.count]));
    return ALL_HOURS.map((item) => ({
      ...item,
      count: map.get(item.hour) ?? 0,
    }));
  }, [data]);

  const summary = useMemo(() => {
    const total = chartData.reduce((sum, item) => sum + item.count, 0);
    let peakHour: number | null = null;
    let peakCount = 0;
    for (const item of chartData) {
      if (item.count > peakCount) {
        peakCount = item.count;
        peakHour = item.hour;
      }
    }
    const activeHours = chartData.filter((item) => item.count > 0).length;
    const zeroHours = 24 - activeHours;
    const average = total / 24;
    const currentCount = chartData[currentHour]?.count ?? 0;
    const peakShare = total > 0 ? Math.round((peakCount / total) * 100) : 0;
    return {
      total,
      peakHour,
      peakCount,
      activeHours,
      zeroHours,
      average,
      currentCount,
      peakShare,
    };
  }, [chartData, currentHour]);

  const peakLabel =
    summary.peakHour !== null
      ? `${String(summary.peakHour).padStart(2, '0')}:00`
      : '-';
  const currentLabel = `${String(currentHour).padStart(2, '0')}:00`;

  return (
    <ChartContainer
      config={{ count: { label: 'Close', color: '#38bdf8' } }}
      className='p-0'
    >
      <div className='border-b border-(--border) px-4 py-3 sm:px-5'>
        <div className='flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between'>
          <div className='max-w-2xl'>
            <div className='flex flex-wrap items-center gap-2'>
              <p className='text-xs font-bold tracking-[0.22em] text-(--text-muted) uppercase'>
                Close per jam WIB
              </p>
              <span className='rounded-full border border-(--border) bg-(--surface-2) px-2.5 py-1 text-[11px] font-semibold text-(--text-secondary)'>
                {dateLabel}
              </span>
            </div>
            <h3 className='mt-1 text-base font-semibold text-(--text-primary)'>
              Distribusi close workorder sepanjang hari
            </h3>
            <p className='mt-1 hidden text-sm leading-6 text-(--text-secondary) sm:block'>
              Pola jam yang paling aktif, jam berjalan, dan titik sepi dibuat
              mudah dibaca supaya user bisa cepat menangkap ritme penyelesaian
              tiket.
            </p>
          </div>

          <div className='grid grid-cols-2 gap-2 sm:grid-cols-4 lg:min-w-115'>
            <StatPill
              label='Total close'
              value={formatNumber(summary.total)}
              sub='hari ini'
              icon={<Activity className='h-4 w-4' />}
            />
            <StatPill
              label='Peak hour'
              value={peakLabel}
              sub={`${formatNumber(summary.peakCount)} tiket`}
              icon={<Flame className='h-4 w-4' />}
            />
            <StatPill
              label='Average'
              value={summary.average.toFixed(1)}
              sub='per jam'
              icon={<Clock3 className='h-4 w-4' />}
            />
            <StatPill
              label='Aktif'
              value={formatNumber(summary.activeHours)}
              sub={`${formatNumber(summary.zeroHours)} jam kosong`}
              icon={<SunMedium className='h-4 w-4' />}
            />
          </div>
        </div>

        <div className='mt-4 flex flex-col gap-2 rounded-2xl border border-(--border) bg-(--surface-2) p-3 sm:flex-row sm:items-center sm:justify-between'>
          <div>
            <p className='text-[10px] font-semibold tracking-[0.18em] text-(--text-muted) uppercase'>
              Filter workzone
            </p>
            <p className='mt-1 text-xs text-(--text-secondary)'>
              Chart close per jam mengikuti workzone yang dipilih.
            </p>
          </div>
          <div className='relative w-full sm:w-65'>
            <select
              value={selectedWorkzone}
              onChange={(e) => setSelectedWorkzone(e.target.value)}
              disabled={workzoneLoading}
              className='w-full cursor-pointer appearance-none rounded-xl border border-(--border) bg-(--surface) px-3 py-2.5 pr-9 text-sm font-medium text-(--text-primary) outline-none focus:ring-2 focus:ring-blue-500/30'
            >
              <option value=''>Semua Workzone</option>
              {workzoneOptions.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
            <span className='pointer-events-none absolute top-1/2 right-3 -translate-y-1/2 text-xs font-bold text-(--text-muted)'>
              ▾
            </span>
          </div>
        </div>
      </div>

      <div className='grid gap-4 p-4 sm:p-5 lg:grid-cols-[minmax(0,1.65fr)_minmax(280px,0.95fr)]'>
        <div className='space-y-4'>
          {isLoading ? (
            <phantom-ui suppressHydrationWarning fallback-radius={8}
              loading
              animation='shimmer'
              reveal={0.12}
              loading-label='Loading hourly close chart'
            >
              <div className='h-70 rounded-2xl border border-(--border) bg-(--surface-2) sm:h-90'>
                <div className='flex h-full flex-col gap-4 p-4'>
                  <div className='flex items-center justify-between gap-3'>
                    <div className='h-4 w-48 rounded-full bg-slate-200 dark:bg-slate-800' />
                    <div className='h-4 w-24 rounded-full bg-slate-100 dark:bg-slate-800/70' />
                  </div>
                  <div className='mt-auto grid grid-cols-12 items-end gap-2'>
                    {Array.from({ length: 12 }).map((_, i) => (
                      <div
                        key={i}
                        className='rounded-t-lg bg-slate-200 dark:bg-slate-800'
                        style={{ height: `${30 + (i % 6) * 11}%` }}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </phantom-ui>
          ) : summary.total === 0 ? (
            <div className='flex h-70 items-center justify-center rounded-2xl border border-dashed border-(--border) bg-(--surface-2) px-6 text-center sm:h-90'>
              <div className='max-w-sm'>
                <MoonStar className='mx-auto h-8 w-8 text-(--text-muted)' />
                <p className='mt-3 text-sm font-semibold text-(--text-primary)'>
                  Belum ada close hari ini
                </p>
                <p className='mt-1 text-sm text-(--text-secondary)'>
                  Chart akan terisi otomatis begitu ada tiket yang selesai di
                  jam berjalan.
                </p>
              </div>
            </div>
          ) : (
            <HourlyCloseChart
              data={chartData}
              currentHour={currentHour}
              peakHour={summary.peakHour}
              isFetching={isFetching}
            />
          )}

          {!isLoading && summary.total > 0 && (
            <div className='hidden grid-cols-2 gap-2 sm:grid-cols-4 md:grid xl:grid-cols-6'>
              {chartData.map((item) => (
                <HourChip
                  key={item.hour}
                  hour={item.hour}
                  count={item.count}
                  currentHour={currentHour}
                  peakHour={summary.peakHour}
                />
              ))}
            </div>
          )}
        </div>

        <div className='space-y-3 md:space-y-4'>
          <div className='rounded-2xl border border-(--border) bg-(--surface-2) p-4 md:p-4'>
            <p className='text-xs font-semibold tracking-[0.18em] text-(--text-muted) uppercase'>
              Insight cepat
            </p>
            <div className='mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-1'>
              <div className='rounded-xl bg-(--surface) p-3'>
                <div className='flex items-center gap-2 text-xs font-semibold tracking-wide text-(--text-muted) uppercase'>
                  <Flame className='h-4 w-4 text-emerald-500' />
                  Jam paling padat
                </div>
                <p className='mt-2 text-2xl font-bold text-(--text-primary)'>
                  {peakLabel}
                </p>
                <p className='mt-1 text-sm text-(--text-secondary)'>
                  {formatNumber(summary.peakCount)} close atau{' '}
                  {summary.peakShare}% dari total close hari ini.
                </p>
              </div>

              <div className='rounded-xl bg-(--surface) p-3'>
                <div className='flex items-center gap-2 text-xs font-semibold tracking-wide text-(--text-muted) uppercase'>
                  <Clock3 className='h-4 w-4 text-amber-500' />
                  Jam berjalan
                </div>
                <p className='mt-2 text-2xl font-bold text-(--text-primary)'>
                  {currentLabel}
                </p>
                <p className='mt-1 text-sm text-(--text-secondary)'>
                  {formatNumber(summary.currentCount)} close tercatat di jam
                  ini. {getHourBadge(currentHour)} ini sedang dipantau.
                </p>
              </div>

              <div className='rounded-xl bg-(--surface) p-3 sm:col-span-2 lg:col-span-1'>
                <div className='flex items-center gap-2 text-xs font-semibold tracking-wide text-(--text-muted) uppercase'>
                  <Activity className='h-4 w-4 text-sky-500' />
                  Rata-rata distribusi
                </div>
                <p className='mt-2 text-2xl font-bold text-(--text-primary)'>
                  {summary.average.toFixed(1)}
                </p>
                <p className='mt-1 text-sm text-(--text-secondary)'>
                  Close per jam dari total {formatNumber(summary.total)} ticket
                  close yang terdistribusi di{' '}
                  {formatNumber(summary.activeHours)} jam aktif.
                </p>
              </div>
            </div>
          </div>

          <div className='hidden rounded-2xl border border-(--border) bg-linear-to-br from-sky-500/10 via-transparent to-emerald-500/10 p-4 md:block'>
            <p className='text-xs font-semibold tracking-[0.18em] text-(--text-muted) uppercase'>
              Cara baca
            </p>
            <ul className='mt-3 space-y-2 text-sm leading-6 text-(--text-secondary)'>
              <li>• Batang tinggi menandakan jam close paling padat.</li>
              <li>
                • Warna hijau menandai peak hour, warna amber menandai jam
                berjalan.
              </li>
              <li>
                • Strip kecil di bawah chart memudahkan scan cepat tanpa membuka
                tooltip.
              </li>
            </ul>
          </div>
        </div>
      </div>
    </ChartContainer>
  );
}
