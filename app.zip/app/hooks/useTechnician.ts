import { useCallback, useEffect, useRef, useState } from 'react';
import { Teknisi } from '@/app/types/teknisi';
import { fetchWithAuth } from '@/app/libs/fetcher';

type TechnicianMeta = {
  ticketId?: number;
  workzone?: string | null;
  serviceAreaId?: number | null;
  serviceAreaName?: string | null;
} | null;

interface RoleApiResponse {
  success: boolean;
  message?: string;
  data?: Teknisi[];
}

interface TicketTechApiResponse {
  success: boolean;
  message?: string;
  data?: {
    ticketId: number;
    workzone: string | null;
    serviceAreaId: number | null;
    serviceAreaName: string | null;
    technicians: Teknisi[];
  };
}

export function useTechnicians() {
  const [technicians, setTechnicians] = useState<Teknisi[]>([]);
  const [meta, setMeta] = useState<TechnicianMeta>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    return () => {
      abortRef.current?.abort();
      abortRef.current = null;
    };
  }, []);

  const fetchTechnicians = useCallback(
    async (opts?: {
      ticketId?: string | number;
      search?: string;
      saId?: number;
    }) => {
      abortRef.current?.abort();
      const controller = new AbortController();
      abortRef.current = controller;
      setLoading(true);
      setError(null);
      setTechnicians([]);
      setMeta(null);

      try {
        const search = opts?.search?.trim();
        const ticketId = opts?.ticketId;
        const saId = opts?.saId;

        const params = new URLSearchParams();
        if (search) params.append('search', search);
        if (saId) params.append('sa_id', String(saId));

        const query = ticketId
          ? `/api/tickets/${encodeURIComponent(String(ticketId))}/technicians${
              params.toString() ? `?${params.toString()}` : ''
            }`
          : search
            ? `/api/users/role/4?search=${encodeURIComponent(search)}`
            : `/api/users/role/4`;

        const res = await fetchWithAuth(query, { signal: controller.signal });

        if (!res || !res.ok) {
          const body = res ? await res.json().catch(() => null) : null;
          throw new Error(body?.message || 'Network response was not ok');
        }

        const data: RoleApiResponse | TicketTechApiResponse = await res.json();

        if (!data.success) {
          throw new Error(data.message || 'Failed to fetch technicians');
        }

        // Ticket-filtered endpoint
        if (ticketId) {
          const payload = (data as TicketTechApiResponse).data;
          const nextTechs = payload?.technicians ?? [];
          const nextMeta: TechnicianMeta = payload
            ? {
                ticketId: payload.ticketId,
                workzone: payload.workzone,
                serviceAreaId: payload.serviceAreaId,
                serviceAreaName: payload.serviceAreaName,
              }
            : null;

          setTechnicians(nextTechs);
          setMeta(nextMeta);
          return;
        }

        // Legacy role-based endpoint
        setMeta(null);
        setTechnicians((data as RoleApiResponse).data ?? []);
        return;
      } catch (err: any) {
        if (controller.signal.aborted) {
          return;
        }
        setError(err.message || 'Failed to load technicians');
        setTechnicians([]);
        setMeta(null);
      } finally {
        if (abortRef.current === controller) {
          abortRef.current = null;
        }
        if (!controller.signal.aborted) {
          setLoading(false);
        }
      }
    },
    [],
  );

  return {
    technicians,
    meta,
    loading,
    error,
    fetchTechnicians,
  };
}
