'use client';

import clsx from 'clsx';
import {
  CheckCircle2,
  CircleDot,
  Clock3,
  FileText,
  MapPin,
  PauseCircle,
  PlayCircle,
  UserRoundPlus,
} from 'lucide-react';
import type { ComponentType } from 'react';
import { Ticket } from '@/app/types/ticket';
import { formatDateTimeWIB } from '@/app/utils/datetime';

interface Props {
  ticket: Ticket;
  status: string;
}

interface TimelineEvent {
  icon: ComponentType<{ size?: number; className?: string }>;
  label: string;
  timestamp: string | null;
  detail?: string | null;
  lines?: Array<string | null>;
  tone: 'gray' | 'blue' | 'purple' | 'green' | 'amber';
}

export default function TicketHistoryTimeline({ ticket, status }: Props) {
  const normalizedStatus = normalizeStatus(
    status || ticket.status_update || ticket.hasilVisit || '',
  );
  const reportedAt = ticket.reportedDate ? new Date(ticket.reportedDate) : null;
  const closedAt = ticket.tracking?.closedAt || ticket.closedAt || null;
  const closedDate = closedAt ? new Date(closedAt) : null;
  const durationLabel =
    reportedAt && closedDate ? formatDuration(reportedAt, closedDate) : null;

  const tracking = ticket.tracking;
  const activityLog = ticket.activityLog ?? [];
  const assignmentHistory = (ticket.assignmentHistory ?? [])
    .slice()
    .sort(
      (a, b) =>
        new Date(a.assignedAt).getTime() - new Date(b.assignedAt).getTime(),
    );

  const reportBy = ticket.reportedBy || ticket.contactName || '—';
  const latestAssignment = assignmentHistory[assignmentHistory.length - 1] ?? null;
  const activeAssignment = assignmentHistory.find((item) => item.isActive) ?? null;

  const assignedBy =
    tracking?.assignedBy ||
    latestAssignment?.assignerName ||
    activeAssignment?.assignerName ||
    findActivityUser(activityLog, ['assign', 'reassign']) ||
    '—';
  const assignedTo =
    tracking?.assignedTo ||
    activeAssignment?.technicianName ||
    latestAssignment?.technicianName ||
    '—';

  const assignCount = assignmentHistory.length || (tracking?.assignedAt ? 1 : 0);
  const reassignCount = Math.max(assignCount - 1, 0);
  const pendingCount = Math.max(
    countActivityMatches(activityLog, ['pending']),
    tracking?.pendingAt ? 1 : 0,
    ticket.pendingDompis ? 1 : 0,
  );
  const hasPending = pendingCount > 0;
  const hasReassign = reassignCount > 0;

  const pendingActivity = findActivityEntry(activityLog, ['pending']);
  const resumeActivity = findActivityEntry(activityLog, ['resume', 'on_progress']);
  const pickupActivity = findActivityEntry(activityLog, ['pickup']);
  const closeActivity = findActivityEntry(activityLog, ['close', 'closed']);

  const events: TimelineEvent[] = [
    {
      icon: CircleDot,
      label: 'Tiket dilaporkan',
      timestamp: ticket.reportedDate,
      detail: ticket.summary || ticket.symptom || ticket.ticket,
      lines: [
        `Dibuka oleh: ${reportBy}`,
        ticket.serviceNo ? `Service: ${ticket.serviceNo}` : null,
        ticket.customerType ? `Pelanggan: ${ticket.customerType}` : null,
        ticket.workzone ? `Workzone: ${ticket.workzone}` : null,
      ],
      tone: 'gray' as const,
    },
    ...(tracking?.assignedAt || assignmentHistory.length > 0
      ? [
          {
            icon: UserRoundPlus,
            label: 'Tiket di-assign',
            timestamp: tracking?.assignedAt || latestAssignment?.assignedAt || null,
            detail: `${assignedBy} → ${assignedTo}`,
            lines: [
              assignCount > 0 ? `Total assign: ${assignCount}x` : null,
              latestAssignment?.isActive ? 'Status: aktif' : null,
            ],
            tone: 'blue' as const,
          },
        ]
      : []),
    ...(tracking?.pickedUpAt || pickupActivity
      ? [
          {
            icon: PlayCircle,
            label: 'Tiket di-pickup',
            timestamp: tracking?.pickedUpAt || pickupActivity?.createdAt || null,
            detail:
              pickupActivity?.description ||
              'Tiket sudah diambil teknisi untuk dikerjakan',
            lines: [
              pickupActivity?.userName ? `Oleh: ${pickupActivity.userName}` : null,
            ],
            tone: 'amber' as const,
          },
        ]
      : []),
    ...(tracking?.onProgressAt || resumeActivity
      ? [
          {
            icon: Clock3,
            label: hasPending ? 'Pengerjaan dilanjutkan' : 'Pengerjaan dimulai',
            timestamp:
              tracking?.onProgressAt ||
              resumeActivity?.createdAt ||
              null,
            detail:
              resumeActivity?.description ||
              (hasPending
                ? 'Teknisi kembali melanjutkan tiket setelah pending'
                : 'Tiket masuk proses pengerjaan'),
            lines: [
              hasPending ? `Pernah pending: ${pendingCount}x` : null,
              resumeActivity?.userName ? `Oleh: ${resumeActivity.userName}` : null,
            ],
            tone: 'blue' as const,
          },
        ]
      : []),
    ...(tracking?.pendingAt || ticket.pendingDompis || pendingActivity
      ? [
          {
            icon: PauseCircle,
            label: 'Tiket dipending',
            timestamp:
              tracking?.pendingAt ||
              pendingActivity?.createdAt ||
              null,
            detail:
              ticket.pendingDompis ||
              pendingActivity?.description ||
              'Tiket sempat masuk status pending',
            lines: [
              pendingActivity?.userName ? `Oleh: ${pendingActivity.userName}` : null,
              pendingCount > 0 ? `Pernah pending: ${pendingCount}x` : null,
            ],
            tone: 'purple' as const,
          },
        ]
      : []),
    ...(closedAt
      ? [
          {
            icon: CheckCircle2,
            label: 'Tiket ditutup',
            timestamp: closedAt,
            detail:
              ticket.descriptionSolutionDompis ||
              ticket.worklogSummary ||
              'Tiket sudah ditutup',
            lines: [
              ticket.rca ? `RCA: ${ticket.rca}` : null,
              ticket.subRca ? `Sub RCA: ${ticket.subRca}` : null,
              durationLabel ? `Durasi tiket: ${durationLabel}` : null,
              closeActivity?.userName ? `Ditutup oleh: ${closeActivity.userName}` : null,
              hasReassign ? `Pernah reassign: ${reassignCount}x` : null,
            ],
            tone: 'green' as const,
          },
        ]
      : []),
  ].filter((event) => event.timestamp || event.detail || event.lines?.length);

  const toneClasses: Record<TimelineEvent['tone'], string> = {
    gray: 'bg-(--surface-2) text-(--text-secondary)',
    blue: 'bg-blue-100 text-blue-600 dark:bg-blue-500/15 dark:text-blue-400',
    amber: 'bg-amber-100 text-amber-600 dark:bg-amber-500/15 dark:text-amber-400',
    purple:
      'bg-purple-100 text-purple-600 dark:bg-purple-500/15 dark:text-purple-400',
    green:
      'bg-green-100 text-green-600 dark:bg-green-500/15 dark:text-green-400',
  };

  const relevantLogs = activityLog.filter((log) => {
    const text = `${log.type ?? ''} ${log.description ?? ''}`.toLowerCase();
    return (
      text.includes('assign') ||
      text.includes('pickup') ||
      text.includes('progress') ||
      text.includes('pending') ||
      text.includes('resume') ||
      text.includes('close')
    );
  });

  return (
    <div className='space-y-4'>
      <div className='rounded-2xl border border-(--border) bg-(--surface) p-4 shadow-sm'>
        <div className='flex items-start justify-between gap-3'>
          <div className='min-w-0'>
            <p className='text-[10px] font-black tracking-widest text-(--text-tertiary) uppercase'>
              Ringkasan Riwayat
            </p>
            <p className='mt-1 text-sm font-bold text-(--text-primary)'>
              {ticket.ticket}
            </p>
            <div className='mt-2 flex flex-wrap gap-2'>
              <Badge label={`Pelapor: ${reportBy}`} />
              <Badge label={`Assign: ${assignedBy} → ${assignedTo}`} />
              <Badge label={`Status: ${normalizedStatus}`} />
              <Badge label={`Pending: ${hasPending ? `${pendingCount}x` : 'Tidak'}`} />
              <Badge label={`Reassign: ${hasReassign ? `${reassignCount}x` : 'Tidak'}`} />
            </div>
          </div>
          {durationLabel ? (
            <div className='rounded-xl border border-(--border) bg-(--surface-2) px-3 py-2 text-right'>
              <p className='text-[10px] font-black tracking-widest text-(--text-tertiary) uppercase'>
                Durasi
              </p>
              <p className='mt-0.5 inline-flex items-center gap-1 text-sm font-bold text-(--text-primary)'>
                <Clock3 size={13} />
                {durationLabel}
              </p>
            </div>
          ) : null}
        </div>
      </div>

      <div className='space-y-0'>
        {events.map((event, i) => {
          const Icon = event.icon;
          const isLast = i === events.length - 1;
          return (
            <div key={`${event.label}-${i}`} className='relative flex gap-3 pb-5'>
              {!isLast && (
                <div className='absolute top-8 left-[15px] h-full w-0.5 bg-(--border-secondary)' />
              )}
              <div
                className={clsx(
                  'z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full',
                  toneClasses[event.tone],
                )}
              >
                <Icon size={15} />
              </div>
              <div className='flex-1 pt-0.5'>
                <p className='text-sm font-bold text-(--text-primary)'>
                  {event.label}
                </p>
                {event.timestamp && (
                  <p className='text-xs text-(--text-tertiary)'>
                    {formatDateTimeWIB(event.timestamp)}
                  </p>
                )}
                {event.detail && (
                  <p className='mt-1 rounded-lg bg-(--surface-2) px-2.5 py-1.5 text-xs text-(--text-secondary)'>
                    {event.detail}
                  </p>
                )}
                {event.lines?.length ? (
                  <div className='mt-1 space-y-1'>
                    {event.lines
                      .filter((line): line is string => Boolean(line))
                      .map((line) => (
                        <div
                          key={line}
                          className='inline-flex max-w-full items-center gap-1.5 rounded-full bg-(--surface-2) px-2.5 py-1 text-[11px] text-(--text-secondary)'
                        >
                          {line?.includes('Workzone') ? (
                            <MapPin size={11} className='shrink-0 text-(--text-tertiary)' />
                          ) : (
                            <FileText size={11} className='shrink-0 text-(--text-tertiary)' />
                          )}
                          <span className='truncate'>{line}</span>
                        </div>
                      ))}
                  </div>
                ) : null}
              </div>
            </div>
          );
        })}
      </div>

      {assignmentHistory.length > 0 && (
        <div className='rounded-2xl border border-(--border) bg-(--surface) p-4 shadow-sm'>
          <p className='text-[10px] font-black tracking-widest text-(--text-tertiary) uppercase'>
            Riwayat Assign
          </p>
          <div className='mt-3 space-y-2'>
            {assignmentHistory.map((item, idx) => (
              <div
                key={item.id}
                className={clsx(
                  'rounded-xl border px-3 py-2.5 text-xs',
                  item.isActive
                    ? 'border-blue-200 bg-blue-50 dark:border-blue-500/20 dark:bg-blue-500/10'
                    : 'border-(--border) bg-(--surface-2)',
                )}
              >
                <div className='flex items-start justify-between gap-3'>
                  <div className='min-w-0'>
                    <p className='font-bold text-(--text-primary)'>
                      {item.technicianName ?? '—'}
                    </p>
                    <p className='mt-0.5 text-(--text-tertiary)'>
                      Di-assign oleh: {item.assignerName ?? 'Sistem'}
                    </p>
                  </div>
                  <div className='text-right text-[10px] text-(--text-tertiary)'>
                    <p>{formatDateTimeWIB(item.assignedAt)}</p>
                    {item.unassignedAt && (
                      <p className='mt-0.5'>
                        Selesai: {formatDateTimeWIB(item.unassignedAt)}
                      </p>
                    )}
                  </div>
                </div>
                <div className='mt-2 flex items-center gap-2'>
                  {idx === 0 && (
                    <span className='inline-flex rounded-full bg-blue-100 px-2 py-0.5 text-[10px] font-bold text-blue-700 dark:bg-blue-500/20 dark:text-blue-300'>
                      Awal
                    </span>
                  )}
                  {item.isActive && (
                    <span className='inline-flex rounded-full bg-green-100 px-2 py-0.5 text-[10px] font-bold text-green-700 dark:bg-green-500/20 dark:text-green-300'>
                      Aktif
                    </span>
                  )}
                  {!item.isActive && (
                    <span className='inline-flex rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-bold text-amber-700 dark:bg-amber-500/20 dark:text-amber-300'>
                      Pindah
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {relevantLogs.length > 0 && (
        <div className='rounded-2xl border border-(--border) bg-(--surface) p-4 shadow-sm'>
          <p className='text-[10px] font-black tracking-widest text-(--text-tertiary) uppercase'>
            Log Aktivitas
          </p>
          <div className='mt-3 space-y-2'>
            {relevantLogs.slice(0, 8).map((log) => (
              <div
                key={log.id}
                className='rounded-xl border border-(--border) bg-(--surface-2) px-3 py-2 text-xs'
              >
                <div className='flex items-start justify-between gap-3'>
                  <div className='min-w-0'>
                    <p className='font-bold text-(--text-primary)'>
                      {log.userName ?? 'Sistem'}
                    </p>
                    <p className='mt-0.5 text-(--text-secondary)'>
                      {log.description ?? log.type ?? 'Aktivitas tiket'}
                    </p>
                  </div>
                  <div className='text-right text-[10px] text-(--text-tertiary)'>
                    <p>{formatDateTimeWIB(log.createdAt)}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function Badge({ label }: { label: string }) {
  return (
    <span className='inline-flex max-w-full items-center rounded-full border border-(--border) bg-(--surface-2) px-2.5 py-1 text-[10px] font-bold text-(--text-secondary) shadow-sm'>
      <span className='truncate'>{label}</span>
    </span>
  );
}

function normalizeStatus(status: string) {
  const value = (status || '').trim().toUpperCase();
  if (!value) return 'OPEN';
  if (value === 'CLOSED') return 'CLOSE';
  return value;
}

function formatDuration(start: Date, end: Date) {
  const diff = Math.max(end.getTime() - start.getTime(), 0);
  const totalMinutes = Math.floor(diff / 60000);
  const days = Math.floor(totalMinutes / 1440);
  const hours = Math.floor((totalMinutes % 1440) / 60);
  const minutes = totalMinutes % 60;

  const parts = [
    days > 0 ? `${days} hari` : null,
    hours > 0 ? `${hours} jam` : null,
    minutes > 0 ? `${minutes} menit` : null,
  ].filter(Boolean);

  return parts.length > 0 ? parts.join(' ') : '0 menit';
}

function findActivityEntry(
  logs: NonNullable<Ticket['activityLog']>,
  keywords: string[],
) {
  return logs.find((log) => {
    const text = `${log.type ?? ''} ${log.description ?? ''}`.toLowerCase();
    return keywords.some((keyword) => text.includes(keyword));
  });
}

function findActivityUser(
  logs: NonNullable<Ticket['activityLog']>,
  keywords: string[],
) {
  return findActivityEntry(logs, keywords)?.userName ?? null;
}

function countActivityMatches(
  logs: NonNullable<Ticket['activityLog']>,
  keywords: string[],
) {
  return logs.filter((log) => {
    const text = `${log.type ?? ''} ${log.description ?? ''}`.toLowerCase();
    return keywords.some((keyword) => text.includes(keyword));
  }).length;
}
