interface InfoFieldProps {
  label: string;
  value?: string | null;
  className?: string;
  variant?: 'default' | 'phone';
  onPhoneClick?: () => void;
}

// Format phone number utility
export function formatPhone(raw: string): string {
  const digits = raw.replace(/\D/g, '').replace(/^0/, '62');
  if (digits.startsWith('62') && digits.length >= 10) {
    // +62 XXX-XXXX-XXXX
    const local = digits.slice(2);
    const p1 = local.slice(0, 3);
    const p2 = local.slice(3, 7);
    const p3 = local.slice(7);
    return `+62 ${p1}-${p2}-${p3}`;
  }
  return raw;
}

export default function InfoField({
  label,
  value,
  className = '',
  variant = 'default',
  onPhoneClick,
}: InfoFieldProps) {
  // Phone variant with action buttons
  if (variant === 'phone' && value) {
    const phoneDigits = value.replace(/\D/g, '');
    const waNumber = phoneDigits.startsWith('62')
      ? phoneDigits
      : phoneDigits.startsWith('0')
        ? '62' + phoneDigits.slice(1)
        : phoneDigits;

    return (
      <div className={className}>
        <p className='mb-1.5 text-[10px] font-bold tracking-wide text-slate-400 dark:text-slate-500 uppercase'>
          {label}
        </p>
        <p className='mb-2 text-sm font-semibold text-slate-800 dark:text-slate-100'>
          {formatPhone(value)}
        </p>
        <div className='flex gap-2'>
          <a
            href={`https://wa.me/${waNumber}`}
            target='_blank'
            rel='noopener noreferrer'
            onClick={(e) => {
              e.stopPropagation();
              onPhoneClick?.();
            }}
            className='flex min-h-10 items-center gap-1.5 rounded-full bg-green-100 px-4 py-2 text-[12px] font-bold text-green-700 transition-colors hover:bg-green-200 dark:bg-green-500/15 dark:text-green-400 dark:hover:bg-green-500/20'
          >
            <svg
              className='h-3.5 w-3.5'
              fill='currentColor'
              viewBox='0 0 24 24'
            >
              <path d='M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z' />
            </svg>
            WhatsApp
          </a>
          <a
            href={`tel:${value}`}
            onClick={(e) => {
              e.stopPropagation();
              onPhoneClick?.();
            }}
            className='flex min-h-10 items-center gap-1.5 rounded-full bg-blue-100 px-4 py-2 text-[12px] font-bold text-blue-700 transition-colors hover:bg-blue-200 dark:bg-blue-500/15 dark:text-blue-400 dark:hover:bg-blue-500/20'
          >
            <span className='text-sm'>📞</span>
            Telepon
          </a>
        </div>
      </div>
    );
  }

  // Default variant
  return (
    <div className={className}>
      <p className='mb-1 text-[10px] font-bold tracking-wide text-slate-400 dark:text-slate-500 uppercase'>
        {label}
      </p>
      {value ? (
        <p className='text-sm font-semibold text-slate-800 dark:text-slate-100'>{value}</p>
      ) : (
        <p className='text-sm font-medium text-slate-300 italic dark:text-slate-600'>
          Tidak tersedia
        </p>
      )}
    </div>
  );
}
