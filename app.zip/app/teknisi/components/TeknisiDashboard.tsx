// app/teknisi/components/TeknisiDashboard.tsx

'use client';

import { useState, useCallback, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import dynamic from 'next/dynamic';
import { Ticket } from '@/app/types/ticket';
import { useToast } from './hooks/useToast';
import {
  CheckCircle2,
  ClipboardList,
  Heart,
  Home,
  LayoutGrid,
  Search,
  Ticket as TicketIcon,
  X,
} from 'lucide-react';

import {
  useTickets,
  usePullToRefresh,
} from './TeknisiDashboard/hooks';
import {
  PullToRefresh,
} from './TeknisiDashboard/components';
import { TicketFilter } from './TeknisiDashboard/constants/ticket';
import DashboardHeader from './DashboardHeader';
import StatusGrid from './StatusGrid';
import FilterChips from './FilterChips';
import TicketCard from './TeknisiDashboard/components/TicketCard';

const TicketDetailModal = dynamic(() => import('./TicketDetailModal'), {
  ssr: false,
  loading: () => null,
});

const TicketUpdateModal = dynamic(() => import('./TicketUpdateModal'), {
  ssr: false,
  loading: () => null,
});

const ToastNotification = dynamic(() => import('./ToastNotification'), {
  ssr: false,
  loading: () => null,
});

interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
}

function SearchBar({ value, onChange }: SearchBarProps) {
  const [inputValue, setInputValue] = useState(value);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Sync if value is reset from outside
  useEffect(() => {
    if (value === '' && inputValue !== '') {
      setInputValue('');
    }
  }, [value]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const v = e.target.value;
    setInputValue(v);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => onChange(v), 300);
  };

  const handleClear = () => {
    setInputValue('');
    if (debounceRef.current) clearTimeout(debounceRef.current);
    onChange('');
  };

  return (
    <div className='relative'>
      <Search className='pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-(--text-tertiary)' />
      <input
        type='text'
        placeholder='Cari nomor tiket... (contoh: INC45671234)'
        value={inputValue}
        onChange={handleChange}
        className='w-full rounded-[28px] border border-(--border) bg-(--surface) py-3 pr-10 pl-10 text-sm text-(--text-primary) shadow-sm transition placeholder:text-(--text-tertiary) focus:border-black focus:ring-2 focus:ring-black/10 focus:outline-none dark:focus:border-white dark:focus:ring-white/10'
      />
      {inputValue && (
        <button
          type='button'
          onClick={handleClear}
          className='absolute top-1/2 right-3 flex h-5 w-5 -translate-y-1/2 items-center justify-center rounded-full bg-(--surface-2) text-(--text-secondary) transition-colors hover:bg-(--surface-3)'
        >
          <X size={12} />
        </button>
      )}
    </div>
  );
}

interface PaginationProps {
  currentPage: number;
  totalPages: number;
  totalItems: number;
  pageSize: number;
  onPageChange: (page: number) => void;
}

function getPageRange(current: number, total: number): (number | '...')[] {
  if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
  const pages: (number | '...')[] = [1];
  if (current > 3) pages.push('...');
  const start = Math.max(2, current - 1);
  const end = Math.min(total - 1, current + 1);
  for (let i = start; i <= end; i++) pages.push(i);
  if (current < total - 2) pages.push('...');
  pages.push(total);
  return pages;
}

function Pagination({
  currentPage,
  totalPages,
  totalItems,
  pageSize,
  onPageChange,
}: PaginationProps) {
  if (totalPages <= 1) return null;

  const from = (currentPage - 1) * pageSize + 1;
  const to = Math.min(currentPage * pageSize, totalItems);
  const pages = getPageRange(currentPage, totalPages);

  const handlePageChange = (page: number) => {
    onPageChange(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className='flex flex-col items-center gap-2 pt-2'>
      <div className='flex items-center gap-1'>
        <button
          type='button'
          onClick={() => handlePageChange(currentPage - 1)}
          disabled={currentPage === 1}
          className='flex min-h-11 items-center rounded-full border border-(--border) bg-(--surface) px-3 text-sm font-medium text-(--text-secondary) transition-colors hover:bg-(--surface-2) disabled:cursor-not-allowed disabled:opacity-50'
        >
          ←
        </button>
        {pages.map((p, i) =>
          p === '...' ? (
            <span
              key={`ellipsis-${i}`}
              className='flex h-8 w-8 items-center justify-center text-sm text-(--text-tertiary)'
            >
              …
            </span>
          ) : (
            <button
              key={`page-${p}`}
              type='button'
              onClick={() => handlePageChange(p as number)}
              className={`flex min-h-11 min-w-11 items-center justify-center rounded-lg text-sm font-medium transition-colors ${
                p === currentPage
                  ? 'bg-black text-white dark:bg-white dark:text-black'
                  : 'text-(--text-secondary) hover:bg-(--surface-2)'
              }`}
            >
              {p}
            </button>
          ),
        )}
        <button
          type='button'
          onClick={() => handlePageChange(currentPage + 1)}
          disabled={currentPage === totalPages}
          className='flex min-h-11 items-center rounded-full border border-(--border) bg-(--surface) px-3 text-sm font-medium text-(--text-secondary) transition-colors hover:bg-(--surface-2) disabled:cursor-not-allowed disabled:opacity-50'
        >
          →
        </button>
      </div>
      <p className='text-xs text-(--text-tertiary)'>
        Menampilkan {from}–{to} dari {totalItems} tiket
      </p>
    </div>
  );
}

export default function TeknisiDashboard() {
  const router = useRouter();
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [showUpdateModal, setShowUpdateModal] = useState(false);

  const { toasts, dismissToast, showSuccess, showError } = useToast();

  const {
    loading,
    filter,
    setFilter,
    paginatedTickets,
    filteredTickets,
    currentPage,
    totalPages,
    setPage,
    searchQuery,
    setSearchQuery,
    stats,
    refresh,
  } = useTickets('all');

  const { pullDistance, ptrReady, ptrRefreshing } = usePullToRefresh({
    onRefresh: refresh,
    disabled: showDetailModal || showUpdateModal,
  });

  const handleSelectTicket = useCallback(
    (ticket: Ticket) => {
      router.push(`/teknisi/ticket/${ticket.idTicket}`);
    },
    [router],
  );

  const handleTicketUpdated = useCallback(
    (type?: 'close' | 'pickup' | 'resume') => {
      void refresh();
      setShowUpdateModal(false);
      setSelectedTicket(null);
      setShowDetailModal(false);
      if (type === 'close') {
        showSuccess(
          'Tiket Berhasil Ditutup!',
          'Tiket telah berhasil di-close.',
        );
      } else if (type === 'pickup') {
        showSuccess(
          'Tiket Diambil',
          'Tiket berhasil di-pickup. Segera kerjakan!',
        );
      } else if (type === 'resume') {
        showSuccess(
          'Tiket Dilanjutkan',
          'Tiket kembali ke status On Progress.',
        );
      }
    },
    [refresh, showSuccess],
  );

  const handleCloseDetail = useCallback(() => {
    setShowUpdateModal(false);
    setShowDetailModal(false);
    setSelectedTicket(null);
  }, []);

  const handleCloseUpdate = useCallback(() => {
    setShowUpdateModal(false);
    setSelectedTicket(null);
  }, []);

  const handleUpdateClick = useCallback(() => {
    setShowDetailModal(false);
    setShowUpdateModal(true);
  }, []);

  const handleUpdateComplete = useCallback(() => {
    setShowUpdateModal(false);
    setSelectedTicket(null);
    void refresh();
    showSuccess('Update Tiket Tersimpan', 'Status tiket berhasil di-pending.');
  }, [refresh, showSuccess]);

  const handlePageChange = useCallback(
    (page: number) => {
      setPage(page);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    },
    [setPage],
  );

  // Dynamic empty state message
  const emptyMessage = (() => {
    if (searchQuery.trim()) {
      return {
        icon: Search,
        title: `Tiket "${searchQuery}" tidak ditemukan`,
        subtitle: 'Coba cek nomor tiket kembali atau hapus pencarian',
        showClearButton: true,
      };
    }
    if (filter === 'closed') {
      return {
        icon: CheckCircle2,
        title: 'Belum ada ticket selesai',
        subtitle: 'Ticket yang selesai akan muncul di sini',
        showClearButton: false,
      };
    }
    return {
      icon: ClipboardList,
      title: 'Tidak ada ticket',
      subtitle: 'Ticket akan muncul ketika ditugaskan kepada Anda',
      showClearButton: false,
    };
  })();

  return (
    <div className='min-h-dvh bg-(--bg) px-4 pt-4 pb-28'>
      {/* Toast Notifications */}
      <ToastNotification toasts={toasts} onDismiss={dismissToast} />

      {/* Pull-to-refresh indicator */}
      <PullToRefresh
        pullDistance={pullDistance}
        ptrReady={ptrReady}
        ptrRefreshing={ptrRefreshing}
      />

      {/* Konten atas — dalam max-w-2xl */}
      <div className='mx-auto max-w-2xl space-y-6'>
        <DashboardHeader
          loading={loading}
          refreshing={ptrRefreshing}
          onRefresh={refresh}
        />

        <StatusGrid
          stats={stats}
          loading={loading}
          activeFilter={filter}
          onFilterChange={setFilter as (f: TicketFilter) => void}
        />

        <div className='space-y-3'>
          <SearchBar value={searchQuery} onChange={setSearchQuery} />
          <FilterChips
            stats={stats}
            activeFilter={filter}
            onFilterChange={setFilter as (f: TicketFilter) => void}
          />
        </div>

        {filteredTickets.length > 0 && (
          <section className='space-y-3'>
            <div className='flex items-end justify-between'>
              <div>
                <p className='text-[10px] font-bold tracking-[0.32em] text-(--text-tertiary) uppercase'>
                  Daftar Ticket
                </p>
                <h2 className='mt-1 text-lg font-semibold text-(--text-primary)'>
                  Semua ticket teknisi
                </h2>
              </div>
              <div className='rounded-full border border-(--border) bg-(--surface-2) px-3 py-1 text-xs font-semibold text-(--text-secondary)'>
                {filteredTickets.length} total
              </div>
            </div>
            <div className='space-y-3'>
              {paginatedTickets.map((ticket) => (
                <TicketCard
                  key={ticket.idTicket}
                  ticket={ticket}
                  onClick={handleSelectTicket}
                />
              ))}
            </div>
          </section>
        )}

        {filteredTickets.length > 0 && (
          <div className='pt-1'>
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              totalItems={filteredTickets.length}
              pageSize={5}
              onPageChange={handlePageChange}
            />
          </div>
        )}

        <section className='space-y-4'>
          {loading ? (
            <div className='flex items-center justify-center py-16'>
              <div className='h-10 w-10 animate-spin rounded-full border-4 border-black border-t-transparent dark:border-white dark:border-t-transparent' />
            </div>
          ) : filteredTickets.length === 0 ? (
            <div className='rounded-4xl border border-dashed border-(--border) bg-(--surface) py-16 text-center shadow-sm'>
              <div className='mb-3 flex justify-center'>
                <emptyMessage.icon className='h-12 w-12 text-(--text-tertiary)' />
              </div>
              <p className='text-lg font-bold text-(--text-primary)'>
                {emptyMessage.title}
              </p>
              <p className='text-sm text-(--text-secondary)'>
                {emptyMessage.subtitle}
              </p>
              {emptyMessage.showClearButton && (
                <button
                  type='button'
                  onClick={() => setSearchQuery('')}
                  className='mt-4 rounded-full bg-black px-4 py-2 text-sm font-bold text-white transition-all active:scale-95'
                >
                  Hapus pencarian
                </button>
              )}
            </div>
          ) : null}
        </section>
      </div>

      {/* Modals */}
      {showDetailModal && selectedTicket && (
        <TicketDetailModal
          ticket={selectedTicket}
          onClose={handleCloseDetail}
          onUpdateClick={handleUpdateClick}
          onUpdated={handleTicketUpdated}
        />
      )}

      {showUpdateModal && selectedTicket && (
        <TicketUpdateModal
          ticket={selectedTicket}
          onClose={handleCloseUpdate}
          onUpdated={handleTicketUpdated}
        />
      )}

      <div className='fixed right-4 bottom-4 left-4 z-40 mx-auto max-w-2xl'>
        <div className='flex items-center justify-between rounded-[28px] bg-(--surface)/80 px-3 py-2 shadow-lg ring-1 ring-(--border) backdrop-blur-xl'>
          {[
            {
              key: 'home',
              icon: Home,
              label: 'Home',
              onClick: () => setFilter('all') as void,
            },
            {
              key: 'tickets',
              icon: TicketIcon,
              label: 'Tickets',
              onClick: () => setFilter('assigned') as void,
            },
            {
              key: 'favorite',
              icon: Heart,
              label: 'Favorite',
              onClick: () => setFilter('pending') as void,
            },
            {
              key: 'grid',
              icon: LayoutGrid,
              label: 'Grid',
              onClick: () => setFilter('closed') as void,
            },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.key}
                type='button'
                onClick={item.onClick}
                className='flex flex-1 flex-col items-center gap-1 rounded-[22px] px-3 py-2 text-[10px] font-bold text-(--text-secondary) transition-all active:scale-95'
              >
                <Icon size={18} />
                {item.label}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
