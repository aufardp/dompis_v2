import { NextResponse } from 'next/server';
import { DashboardAggregationService } from '@/app/libs/services/dashboard-aggregation.service';
import { protectApi } from '@/app/libs/protectApi';
import { getErrorMessage, getErrorStatus } from '@/app/libs/apiError';
import { getCache, setCache } from '@/lib/cache';

const CACHE_TTL = 60;

export const dynamic = 'force-dynamic';

function buildCacheKey(
  role: string,
  userId: number,
  workzone?: string,
): string {
  return `dashboard:summary:${role}:${userId}:${workzone ?? 'all'}`;
}

export async function GET(request: Request) {
  try {
    const user = await protectApi([
      'admin',
      'teknisi',
      'helpdesk',
      'superadmin',
      'super_admin',
    ]);

    const { searchParams } = new URL(request.url);
    const workzone = searchParams.get('workzone') || undefined;

    const cacheKey = buildCacheKey(user.role, user.id_user, workzone);

    const cached = await getCache(cacheKey);
    if (cached) {
      return NextResponse.json({
        success: true,
        data: cached,
        cached: true,
      });
    }

    const summary = await DashboardAggregationService.getDailySummary({
      role: user.role,
      userId: user.id_user,
      workzone,
    });

    await setCache(cacheKey, summary, CACHE_TTL);

    return NextResponse.json({
      success: true,
      data: summary,
    });
  } catch (error: unknown) {
    console.error('[Dashboard Summary] Error:', error);
    return NextResponse.json(
      {
        success: false,
        message: getErrorMessage(error, 'Error fetching dashboard summary'),
      },
      { status: getErrorStatus(error, 500) },
    );
  }
}
