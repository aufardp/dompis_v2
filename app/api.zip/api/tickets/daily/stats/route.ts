import { NextResponse } from 'next/server';
import { DailyTicketService } from '@/app/libs/services/daily-ticket.service';
import { protectApi } from '@/app/libs/protectApi';
import { getErrorMessage, getErrorStatus } from '@/app/libs/apiError';
import { getCache, setCache } from '@/lib/cache';

export const dynamic = 'force-dynamic';

const DAILY_STATS_CACHE_TTL = 60;

function buildDailyStatsCacheKey(
  workzone?: string,
  dept?: string,
  ticketType?: string,
  statusUpdate?: string,
): string {
  const params = new URLSearchParams();
  if (workzone) params.set('workzone', workzone);
  if (dept) params.set('dept', dept);
  if (ticketType) params.set('ticketType', ticketType);
  if (statusUpdate) params.set('statusUpdate', statusUpdate);
  params.sort();
  return `daily_stats:${params.toString()}`;
}

/**
 * GET /api/tickets/daily/stats
 *
 * Returns stats for the daily ticket table.
 */
export async function GET(request: Request) {
  try {
    const user = await protectApi([
      'admin',
      'helpdesk',
      'superadmin',
      'super_admin',
    ]);

    const { searchParams } = new URL(request.url);

    const workzone = searchParams.get('workzone') || undefined;
    const dept = searchParams.get('dept') || undefined;
    const ticketType = searchParams.get('ticketType') || undefined;
    const statusUpdate = searchParams.get('statusUpdate') || undefined;

    // Build cache key
    const cacheKey = buildDailyStatsCacheKey(
      workzone,
      dept,
      ticketType,
      statusUpdate,
    );

    // Try to get from cache
    const cached = await getCache(cacheKey);
    if (cached) {
      return NextResponse.json({
        success: true,
        data: cached,
        cached: true,
      });
    }

    // Fetch stats
    const [stats, byServiceArea] = await Promise.all([
      DailyTicketService.getDailyStats(user.role, user.id_user, undefined, {
        dept,
        ticketType,
        statusUpdate,
      }),
      DailyTicketService.getDailyStatsByServiceArea(
        user.role,
        user.id_user,
        undefined,
        {
          dept,
          ticketType,
          statusUpdate,
        },
      ),
    ]);

    const result = {
      ...stats,
      byServiceArea,
    };

    // Cache the result
    await setCache(cacheKey, result, DAILY_STATS_CACHE_TTL);

    return NextResponse.json({
      success: true,
      data: result,
    });
  } catch (error: unknown) {
    return NextResponse.json(
      {
        success: false,
        message: getErrorMessage(error, 'Error fetching daily ticket stats'),
      },
      { status: getErrorStatus(error, 500) },
    );
  }
}
